# Lokaler Abgleichsbericht (reproduzierbare Snapshot-Auswertung)

- Repository: `oORaxaOo/KOR-NEXUS` / Branch `main`
- Snapshot-HEAD: `d7feb9a6e24d1015de7140531f42971bf5d81bd1`
- Lokale Dateien inventarisiert: 52
- Hinweis: Die Remote-Blob-SHA ist SHA-1, die lokale Prüfsumme SHA-256; diese Werte sind nicht direkt vergleichbar.
- Dieser Bericht liest nur lokale Dateien und den eingebetteten, dokumentierten Snapshot. Er nutzt kein Netzwerk und schreibt nichts nach GitHub.

## Dateivergleich

| Status | Datei | Lokal Bytes | Remote Bytes |
|---|---|---:|---:|
| LOCAL-ONLY | `.github/workflows/release.yml` | 3563 | — |
| LOCAL-ONLY | `CHANGELOG.md` | 10934 | — |
| LOCAL-ONLY | `CI_MANUAL_START.md` | 2097 | — |
| LOCAL-ONLY | `DECISIONS.md` | 16158 | — |
| LOCAL-ONLY | `EXPORT_SCHEMA.md` | 4820 | — |
| LOCAL-ONLY | `LICENSE` | 323 | — |
| LOCAL-ONLY | `PKGBUILD` | 1938 | — |
| LOCAL-ONLY | `PROJECT_STATUS.md` | 19572 | — |
| REMOTE-LOCAL-DIFFERENT | `README.md` | 21963 | 49 |
| LOCAL-ONLY | `REPOSITORY_TRANSFER_CHECKLIST.md` | 1477 | — |
| LOCAL-ONLY | `REPOSITORY_TRANSFER_PLAN.md` | 5565 | — |
| LOCAL-ONLY | `SOURCE_SHA256SUMS.txt` | 96 | — |
| LOCAL-ONLY | `core/__init__.py` | 34 | — |
| LOCAL-ONLY | `core/server.py` | 92960 | — |
| LOCAL-ONLY | `core/test_server.py` | 38389 | — |
| LOCAL-ONLY | `install-user.sh` | 4128 | — |
| LOCAL-ONLY | `kor-workstation-1.10.0.tar.gz` | 234332 | — |
| LOCAL-ONLY | `kor-workstation-1.11.0.tar.gz` | 237498 | — |
| LOCAL-ONLY | `kor-workstation-1.12.0.tar.gz` | 242493 | — |
| LOCAL-ONLY | `kor-workstation-1.13.0.tar.gz` | 244753 | — |
| LOCAL-ONLY | `kor-workstation-1.14.0.tar.gz` | 244004 | — |
| LOCAL-ONLY | `kor-workstation-1.15.0.tar.gz` | 245170 | — |
| LOCAL-ONLY | `kor-workstation-1.16.0.tar.gz` | 246941 | — |
| LOCAL-ONLY | `kor-workstation-1.17.0.tar.gz` | 248966 | — |
| LOCAL-ONLY | `kor-workstation-1.18.0.tar.gz` | 250928 | — |
| LOCAL-ONLY | `kor-workstation-1.19.0.tar.gz` | 251767 | — |
| LOCAL-ONLY | `kor-workstation-1.20.0.tar.gz` | 262707 | — |
| LOCAL-ONLY | `kor-workstation-1.9.0.tar.gz` | 226657 | — |
| LOCAL-ONLY | `launch.sh` | 225 | — |
| LOCAL-ONLY | `packaging/icons/kor-workstation.svg` | 478 | — |
| LOCAL-ONLY | `packaging/kor-workstation-launcher.sh` | 564 | — |
| LOCAL-ONLY | `packaging/kor-workstation-stop.sh` | 1321 | — |
| LOCAL-ONLY | `packaging/kor-workstation.desktop` | 342 | — |
| LOCAL-ONLY | `preview/hud-redesign-desktop.png` | 657058 | — |
| LOCAL-ONLY | `preview/hud-redesign-mobile.png` | 355036 | — |
| LOCAL-ONLY | `preview/smoke-test.png` | 657058 | — |
| LOCAL-ONLY | `scripts/build-arch-package.sh` | 919 | — |
| LOCAL-ONLY | `scripts/ci.sh` | 611 | — |
| LOCAL-ONLY | `scripts/create-source-archive.py` | 3339 | — |
| LOCAL-ONLY | `scripts/prepare-repository-sync.py` | 4597 | — |
| LOCAL-ONLY | `scripts/qa-preview-playwright.py` | 27554 | — |
| LOCAL-ONLY | `scripts/release-check.sh` | 5019 | — |
| LOCAL-ONLY | `scripts/test-built-package-installation.sh` | 5350 | — |
| LOCAL-ONLY | `scripts/test-installation.sh` | 5948 | — |
| LOCAL-ONLY | `scripts/verify-built-package.py` | 1201 | — |
| LOCAL-ONLY | `scripts/verify-source.sh` | 2774 | — |
| LOCAL-ONLY | `stop.sh` | 1327 | — |
| LOCAL-ONLY | `uninstall-user.sh` | 1345 | — |
| LOCAL-ONLY | `web/app.js` | 67370 | — |
| LOCAL-ONLY | `web/geodata/world.geojson` | 364876 | — |
| LOCAL-ONLY | `web/index.html` | 23938 | — |
| LOCAL-ONLY | `web/styles.css` | 50029 | — |

## Interpretationsregeln

- `LOCAL-ONLY`: lokal vorhanden, im geprüften Remote-Baum nicht enthalten; Kandidat für kontrollierte Übertragung.
- `REMOTE-ONLY`: im Remote-Baum vorhanden, lokal nicht vorhanden; vor Übertragung sichern und manuell behandeln.
- `REMOTE-LOCAL-*`: gleicher Pfad; vor Ersetzen Inhalt vergleichen. Gleiche Größe beweist keine Inhaltsgleichheit.
- Vor einer realen Synchronisation zuerst Remote-HEAD und Baum erneut abfragen. Bei abweichendem HEAD ist dieser Snapshot veraltet.
