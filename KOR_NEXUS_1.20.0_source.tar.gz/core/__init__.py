"""KOR-NEXUS application core."""
