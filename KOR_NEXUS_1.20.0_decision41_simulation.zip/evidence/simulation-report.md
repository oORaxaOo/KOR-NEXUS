# Entscheidung 41 — lokale Erstübertragungssimulation

**Status: lokaler Dry-Run abgeschlossen; keine Remote-Schreibaktionen.**

- Repository-Snapshot: `oORaxaOo/KOR-NEXUS`, Branch `main`, dokumentierter HEAD `d7feb9a6e24d1015de7140531f42971bf5d81bd1`
- Isolierter simulierter Basis-Commit: `1b0b8f9654df92be58e05151a14b677cfb51c8fa` (lokal erzeugt, kein echter Remote-Commit)
- Lokale Übertragungskandidaten inventarisiert: 40 Dateien
- Dateien im Kandidaten nach Overlay (ohne `.git`): 40

## README.md — expliziter Konfliktentscheid

- Remote-Snapshot enthält nur den Platzhalter-README (49 Bytes); die lokale README ist eine umfangreiche Projekt-/Release-Dokumentation.
- Der Kandidat nutzt die lokale README als vorgeschlagene Fassung. Beide Originalvarianten sind separat in `evidence/README.remote-original.md` und `evidence/README.local-candidate.md` erhalten.
- Dies ist nur ein lokaler Vorschlag, keine Freigabe zum Remote-Overwrite. Vor einem echten Transfer muss der Remote-HEAD neu geprüft werden.

## Kritische Dateien / Erhaltung

| Datei | Erhalten |
|---|---:|
| `core/server.py` | JA |
| `core/test_server.py` | JA |
| `web/app.js` | JA |
| `web/index.html` | JA |
| `web/styles.css` | JA |
| `web/geodata/world.geojson` | JA |
| `README.md` | JA |
| `CHANGELOG.md` | JA |
| `PROJECT_STATUS.md` | JA |
| `EXPORT_SCHEMA.md` | JA |
| `DECISIONS.md` | JA |
| `.github/workflows/release.yml` | JA |
| `scripts/ci.sh` | JA |
| `scripts/release-check.sh` | JA |
| `PKGBUILD` | JA |

## Offline-Geodaten

- `web/geodata/world.geojson`: 364876 Bytes, 177 Features, FeatureCollection gültig.
- SHA-256: `8cde92ef2b36f541578c34947081fdb387677f8371134c6b49c11e9fc9e15f6d`; Quell-/Kandidaten-Hashes identisch: **True**.

## CI

- Erhalten: `.github/workflows/release.yml`, `scripts/ci.sh`, `scripts/release-check.sh`.
- Im dokumentierten Remote-Snapshot gab es keinen Workflow; die Workflow-Datei ist im Vergleich also eine neue lokale Datei.

## Ausschlüsse

- Historische Quellarchive `kor-workstation-1.9.0.tar.gz` bis `kor-workstation-1.20.0.tar.gz` werden nicht in den Kandidaten kopiert.
- `.git`, `__pycache__`, `*.pyc` und bereits generierte Sync-Berichte sind ausgeschlossen. Externe Release-Artefakte bleiben außerhalb des Simulationsbereichs und unverändert.

## Lokale Tests und Artefakte

- Kern-Unit-Tests im Kandidaten: **29/29 bestanden**.
- Python-Syntax: **5 Dateien bestanden**; Shell-Syntax: **7 Skripte bestanden**.
- Workflow-Datei statisch vorhanden und mit `name`/`jobs` geprüft.
- Externe Release-ZIP/TAR: SHA-256 unverändert, Archivintegrität bestanden.

## Lokale Tests und Artefakte

- Kern-Unit-Tests im Kandidaten: **29/29 bestanden**.
- Python-Syntax: **5 Dateien bestanden**; Shell-Syntax: **7 Skripte bestanden**.
- Workflow-Datei statisch vorhanden und mit `name`/`jobs` geprüft.
- Externe Release-ZIP/TAR: SHA-256 unverändert, Archivintegrität bestanden.

## Remote-Schreibaktionen

Keine: kein Remote-Branch, Commit, Push, Pull Request, Workflow-Dispatch oder Release. Der simulierte Kandidat besitzt keine Git-Remote-URL.

## Git-Overlay-Status (Simulation)

```text
A  .github/workflows/release.yml
A  CHANGELOG.md
A  CI_MANUAL_START.md
A  DECISIONS.md
A  EXPORT_SCHEMA.md
A  LICENSE
A  PKGBUILD
A  PROJECT_STATUS.md
M  README.md
A  REPOSITORY_TRANSFER_CHECKLIST.md
A  REPOSITORY_TRANSFER_PLAN.md
A  SOURCE_SHA256SUMS.txt
A  core/__init__.py
A  core/server.py
A  core/test_server.py
A  install-user.sh
A  launch.sh
A  packaging/icons/kor-workstation.svg
A  packaging/kor-workstation-launcher.sh
A  packaging/kor-workstation-stop.sh
A  packaging/kor-workstation.desktop
A  preview/hud-redesign-desktop.png
A  preview/hud-redesign-mobile.png
A  preview/smoke-test.png
A  scripts/build-arch-package.sh
A  scripts/ci.sh
A  scripts/create-source-archive.py
A  scripts/prepare-repository-sync.py
A  scripts/qa-preview-playwright.py
A  scripts/release-check.sh
A  scripts/test-built-package-installation.sh
A  scripts/test-installation.sh
A  scripts/verify-built-package.py
A  scripts/verify-source.sh
A  stop.sh
A  uninstall-user.sh
A  web/app.js
A  web/geodata/world.geojson
A  web/index.html
A  web/styles.css
```

## Ergebnis

Der lokale Dry-Run erhält die geprüften Kernbereiche, Offline-Karte, Dokumentation und CI-Dateien. Der einzige vorhandene Remote-Pfad `README.md` ist als Inhaltskonflikt dokumentiert und nur im isolierten Kandidaten ersetzt. Diese Simulation ist keine Freigabe zum Schreiben nach GitHub.
