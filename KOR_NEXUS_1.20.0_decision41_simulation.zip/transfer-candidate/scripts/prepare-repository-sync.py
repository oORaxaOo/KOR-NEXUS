#!/usr/bin/env python3
"""Create a deterministic local-vs-remote snapshot report; never accesses the network."""
from pathlib import Path
import hashlib, json, sys

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'repository-sync-preparation'
REMOTE = {
    'repository': 'oORaxaOo/KOR-NEXUS',
    'branch': 'main',
    'head_sha': 'd7feb9a6e24d1015de7140531f42971bf5d81bd1',
    'tree_sha': 'd7feb9a6e24d1015de7140531f42971bf5d81bd1',
    'files': {
        'README.md': {
            'size': 49,
            'sha': 'cbfde5964e51fa3a44bd5bba0795e2ff8fb83a95',
            'note': 'Git blob SHA-1 from read-only GitHub API snapshot; not a SHA-256.'
        }
    },
    'snapshot_warning': 'Snapshot captured 2026-10-16; refresh remote metadata before any future write.'
}
EXCLUDE_DIRS = {'.git', '__pycache__', 'repository-sync-preparation'}
EXCLUDE_SUFFIXES = {'.pyc'}

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def local_files():
    rows = []
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT)
        if any(part in EXCLUDE_DIRS for part in rel.parts) or p.suffix in EXCLUDE_SUFFIXES:
            continue
        if rel.parts and rel.parts[0] == 'repository-sync-preparation':
            continue
        rows.append({'path': rel.as_posix(), 'size': p.stat().st_size, 'sha256': sha256(p)})
    return rows

def main():
    OUT.mkdir(exist_ok=True)
    local = local_files()
    remote_paths = set(REMOTE['files'])
    local_by_path = {x['path']: x for x in local}
    local_paths = set(local_by_path)
    rows = []
    for path in sorted(local_paths | remote_paths):
        l = local_by_path.get(path)
        r = REMOTE['files'].get(path)
        if l and r:
            status = 'REMOTE-LOCAL-DIFFERENT' if l['size'] != r['size'] else 'REMOTE-LOCAL-CONTENT-REVIEW'
            # GitHub blob SHA-1 cannot be compared directly with local SHA-256; size is only a hint.
        elif l:
            status = 'LOCAL-ONLY'
        else:
            status = 'REMOTE-ONLY'
        rows.append({'path': path, 'status': status, 'local_size': l['size'] if l else None,
                     'local_sha256': l['sha256'] if l else None,
                     'remote_size': r['size'] if r else None,
                     'remote_blob_sha1': r['sha'] if r else None})
    payload = {'schema_version': 1, 'mode': 'offline-snapshot-comparison-no-network-no-writes',
               'remote_snapshot': REMOTE, 'local_root': str(ROOT), 'local_files': local, 'comparison': rows}
    (OUT / 'comparison.json').write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    lines = ['# Lokaler Abgleichsbericht (reproduzierbare Snapshot-Auswertung)', '',
             f"- Repository: `{REMOTE['repository']}` / Branch `{REMOTE['branch']}`",
             f"- Snapshot-HEAD: `{REMOTE['head_sha']}`",
             f'- Lokale Dateien inventarisiert: {len(local)}',
             '- Hinweis: Die Remote-Blob-SHA ist SHA-1, die lokale Prüfsumme SHA-256; diese Werte sind nicht direkt vergleichbar.',
             '- Dieser Bericht liest nur lokale Dateien und den eingebetteten, dokumentierten Snapshot. Er nutzt kein Netzwerk und schreibt nichts nach GitHub.', '',
             '## Dateivergleich', '', '| Status | Datei | Lokal Bytes | Remote Bytes |', '|---|---|---:|---:|']
    for x in rows:
        lines.append(f"| {x['status']} | `{x['path']}` | {x['local_size'] if x['local_size'] is not None else '—'} | {x['remote_size'] if x['remote_size'] is not None else '—'} |")
    lines += ['', '## Interpretationsregeln', '',
              '- `LOCAL-ONLY`: lokal vorhanden, im geprüften Remote-Baum nicht enthalten; Kandidat für kontrollierte Übertragung.',
              '- `REMOTE-ONLY`: im Remote-Baum vorhanden, lokal nicht vorhanden; vor Übertragung sichern und manuell behandeln.',
              '- `REMOTE-LOCAL-*`: gleicher Pfad; vor Ersetzen Inhalt vergleichen. Gleiche Größe beweist keine Inhaltsgleichheit.',
              '- Vor einer realen Synchronisation zuerst Remote-HEAD und Baum erneut abfragen. Bei abweichendem HEAD ist dieser Snapshot veraltet.', '']
    (OUT / 'comparison.md').write_text('\n'.join(lines), encoding='utf-8')
    print(f'OK: {len(local)} lokale Dateien inventarisiert; Bericht: {OUT / "comparison.md"}')
    print('READ-ONLY: kein Netzwerk, keine GitHub-Schreibaktion.')

if __name__ == '__main__':
    main()
