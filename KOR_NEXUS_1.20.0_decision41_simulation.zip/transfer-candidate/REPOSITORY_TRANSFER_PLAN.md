# KOR-NEXUS 1.20.0 — kontrollierter Repository-Transferplan

Stand der Prüfung: 2026-10-16. Dieser Plan ist **read-only gegenüber GitHub**. Es wurden keine Remote-Änderungen vorgenommen.

## Verifizierter Remote-Zustand

- Repository: https://github.com/oORaxaOo/KOR-NEXUS
- Standardbranch und vorhandener Branch: `main`
- Remote-HEAD: `d7feb9a6e24d1015de7140531f42971bf5d81bd1`
- Tree-SHA: `d7feb9a6e24d1015de7140531f42971bf5d81bd1`
- Remote-Baum (rekursiv): ausschließlich `README.md` (49 Bytes; Blob-SHA `cbfde5964e51fa3a44bd5bba0795e2ff8fb83a95`)
- Remote-README: `# KOR-NEXUS` und `The Kor Nexus Command Center Project`
- Berechtigungen des verbundenen GitHub-Zugangs laut Repository-Metadaten: `admin=true`, `maintain=true`, `push=true`, `pull=true`. Das beweist technische Rechte, ist aber **keine Freigabe für einen Schreibvorgang**.
- Actions-Abfrage: `total_count=0`, keine Workflow-Runs vorhanden.
- `.github/workflows/release.yml` auf Remote-`main`: 404/nicht vorhanden.
- Lokales Verzeichnis ist kein Git-Repository (kein `.git`, kein konfigurierter Remote). Es gibt daher keinen lokalen Commit-Hash und keinen verlässlichen Git-Diff gegen Remote.

## Sicherheitsentscheidung

Remote enthält nur einen README-Platzhalter. Der lokale Projektstand ist wesentlich umfangreicher. **Kein Pull/Merge/Checkout auf den Projektordner und kein pauschales Überschreiben**: Das könnte die lokale Anwendung ersetzen oder löschen. Ebenso wird der Remote-README nicht stillschweigend mit dem lokalen README gleichgesetzt. Die Synchronisation ist als erste kontrollierte Initialisierung zu behandeln.

## Übertragungsumfang

### In den Versionskontrollstand aufnehmen

- Anwendungslogik: `core/` (inkl. Tests)
- Frontend: `web/` inklusive `web/geodata/world.geojson` (Offline-Karte)
- Installer, Start-/Stop-/Deinstallationsskripte
- `packaging/` einschließlich Desktop-Datei, Launcher und Icon
- `scripts/` einschließlich reproduzierbarer Archivierung, QA, Release- und CI-Checks
- `.github/workflows/release.yml`
- `PKGBUILD`, `LICENSE`, `README.md`, `CHANGELOG.md`, `DECISIONS.md`, `PROJECT_STATUS.md`, `EXPORT_SCHEMA.md`, `CI_MANUAL_START.md`, `SOURCE_SHA256SUMS.txt`
- `preview/` QA-/Design-Screenshots (prüfen, ob sie im Repository erwünscht sind; derzeit im lokalen Entwicklungsbestand enthalten)

### Nicht blind committen

- `__pycache__/`, `*.pyc`, temporäre Testprofile, lokale Datenbanken, persönliche Konfigurationen, Zugangsdaten und Logs.
- Historische Quellarchive `kor-workstation-1.9.0.tar.gz` bis `kor-workstation-1.19.0.tar.gz`: erhalten, aber nicht automatisch in den Git-Verlauf übernehmen.
- Das geprüfte Release-Archiv `kor-workstation-1.20.0.tar.gz`: erhalten und per SHA-256 verifizieren; der Workflow erzeugt/archiviert Build-Artefakte. Vor einem Commit entscheiden, ob es zusätzlich versioniert werden soll (Standardempfehlung: nein).
- Externe Download-Artefakte `KOR_NEXUS_1.20.0_development.zip`, `KOR_NEXUS_1.20.0_source.tar.gz`, `KOR_NEXUS_1.20.0_SHA256SUMS.txt` liegen außerhalb des Projektordners und werden nicht automatisch in Git kopiert.

## Reihenfolge des späteren Transfers

1. Diese Prüfung und alle Release-Prüfsummen archivieren; aktuelle lokale Backups unangetastet lassen.
2. Frischen Remote-Snapshot von `main` und Branch-HEAD abrufen; gegen die hier dokumentierten SHAs vergleichen. Bei Änderung: Plan abbrechen und Diff neu erstellen.
3. Separaten lokalen Git-Arbeitsbereich oder frisches Klon-Verzeichnis anlegen; niemals den einzigen Projektordner als Klon-Ziel verwenden.
4. Remote-Inhalt in diesem isolierten Bereich sichern und lokalen Quellstand kontrolliert einspielen. Bestehende Remote-Dateien einzeln behandeln; `README.md` als Konflikt markieren, nicht ungeprüft überschreiben.
5. Dateiliste und SHA-256 vergleichen; Geodaten-Dateigröße und Feature-Anzahl validieren; sicherstellen, dass keine lokalen Daten, Geheimnisse oder Cache-Dateien einfließen.
6. Vollständige lokale Tests in sauberem Arbeitsbereich ausführen; CI-Workflow auf Syntax, Actions-Versionen, Berechtigungen und Laufzeit prüfen.
7. Vor dem ersten Remote-Schreibvorgang ausdrückliche Freigabe einholen, die mindestens Repository, Zielbranch, genaue Aktion (Branch/Commit/Push/PR) und erlaubten Umfang nennt. Allgemeines Interesse am Projekt reicht nicht.
8. Erst nach Freigabe einen isolierten Feature-Branch anlegen; niemals direkt auf `main` schreiben. Push und PR sind getrennte, ausdrücklich zu genehmigende Schritte.

## Explizite Freigabe für einen späteren Schreibschritt

Erforderlich ist eine eindeutige Nachricht des Nutzers, zum Beispiel: „Ich genehmige das Anlegen des Branches `kor-nexus-1.20.0-transfer` in `oORaxaOo/KOR-NEXUS` und das Hochladen des geprüften lokalen Projektstands auf diesen Branch; `main` bleibt unverändert. Vor dem Erstellen eines Pull Requests bitte erneut fragen.“

Diese Beispiel-Formulierung ist **keine bereits erteilte Freigabe**. Keine Branch-, Commit-, Push-, PR-, Workflow-Dispatch- oder Release-Aktion ist Teil dieser Entscheidung 38.

## Offene Grenzen

- GitHub meldet derzeit keine Actions-Runs; eine erfolgreiche Remote-CI ist nicht nachgewiesen.
- Der native Arch-Paketbau kann in dieser Debian-Umgebung ohne `makepkg`/`pacman` nicht verifiziert werden.
- Der vollständige kombinierte lokale `release-check.sh full`-Aufruf hatte zuvor ein Zeitlimit erreicht; die Unit-Tests, Browser-QA, Installationstests und der Quick-Release-Check wurden separat erfolgreich ausgeführt. Der Gesamtmodus `full` wird deshalb nicht als erfolgreich behauptet.
