# Transfer-Checkliste — KOR-NEXUS 1.20.0

## Read-only Vorprüfung
- [x] Repository eindeutig identifiziert: `oORaxaOo/KOR-NEXUS`
- [x] `main` und Remote-HEAD ermittelt
- [x] Rekursiven Remote-Dateibaum geprüft
- [x] Remote-README und Blob-SHA geprüft
- [x] Repository-Metadaten/Berechtigungen geprüft
- [x] Actions-Runs abgefragt (keine vorhanden)
- [x] Remote-Workflow-Datei geprüft (nicht vorhanden; 404)
- [x] Lokales Git-Metadaten-Verzeichnis geprüft (fehlt)
- [x] Lokale Release-Prüfsummen geprüft
- [x] Keine Remote-Schreibaktion durchgeführt

## Vor jedem späteren Schreibvorgang
- [ ] Remote-HEAD erneut lesen und mit `d7feb9a6e24d1015de7140531f42971bf5d81bd1` vergleichen
- [ ] Neuen Remote-Baum exportieren und Dateidifferenzen neu erzeugen
- [ ] Lokalen Stand in isoliertem Git-Arbeitsbereich sichern
- [ ] README-Konflikt explizit entscheiden
- [ ] Offline-GeoJSON und Feature-Anzahl prüfen
- [ ] Geheimnisse, Cache, Logs, lokale Nutzerdaten ausschließen
- [ ] Release-Archive und SHA-256 unverändert nachweisen
- [ ] Tests in sauberem Arbeitsbereich erfolgreich ausführen
- [ ] Workflow auf Berechtigungen und Ausführbarkeit prüfen
- [ ] Explizite Freigabe für konkrete Aktion und Branch erhalten
- [ ] Nur genehmigte Aktion durchführen; `main` nicht direkt ändern
- [ ] Ergebnis und neue SHAs protokollieren

## Freigabestatus
**NICHT FREIGEGEBEN** — diese Entscheidung erlaubt ausschließlich lokale Vorbereitung und read-only Prüfungen.
